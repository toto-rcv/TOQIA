"use client";

import Link from "next/link";
import { ArrowLeft, X } from "lucide-react";
import * as React from "react";

import type { MenuCategoryRow, MenuItemRow } from "@/db/queries/menu";
import { MenuIcon } from "./menu-icons";
import type { LandingData } from "./landing-view";

/**
 * La carta del local, tal como la ve el cliente.
 *
 * Ambiente propio, distinto de la portada negra: fondo arena, tipografía
 * redonda y bandas de color por categoría. La carta se lee sentado a la mesa,
 * con la luz de la sala; un fondo claro cansa mucho menos que texto claro
 * sobre negro, y una serif editorial hace parecer cara una milanesa.
 *
 * Jerarquía, de más a menos peso visual:
 *   categoría (banda de color) → nombre → precio → descripción → foto
 *
 * Una sola columna que se ensancha con la pantalla:
 *
 *  - **Celular**: cabecera con el nombre, la foto y las categorías debajo.
 *  - **Escritorio (≥1024px)**: la foto pasa a ser un hero a todo el ancho de
 *    la ventana, y los platos se acomodan de a dos por fila.
 *
 * Es un componente de cliente por una sola cosa que necesita el navegador: el
 * visor de fotos ampliadas.
 */
export function MenuView({
  landing,
  categories,
  currency,
  backHref,
}: {
  landing: LandingData;
  categories: MenuCategoryRow[];
  currency: string;
  /** A dónde vuelve el botón de atrás: siempre la página de esa pulsera. */
  backHref: string;
}) {
  const nombre = landing.displayName?.trim() || landing.name;

  const [ampliada, setAmpliada] = React.useState<MenuItemRow | null>(null);

  // Una categoría sin platos visibles no aporta nada y deja un título huérfano.
  const conPlatos = React.useMemo(
    () => categories.filter((categoria) => categoria.items.length > 0),
    [categories]
  );

  return (
    <main className="tq-menu-page tq-menu">
      {/* El hero va fuera del contenedor centrado para poder ocupar todo el
          ancho de la ventana, de borde a borde. */}
      <Hero landing={landing} nombre={nombre} backHref={backHref} />

      {/* ── Cabecera (celular) ─────────────────────────────────────────
          Va con su propio padding, fuera del contenedor de la carta: la foto
          de abajo tiene que llegar a los bordes de la pantalla y no podía
          compartir el `px-4`. */}
      <header className="mx-auto flex w-full max-w-[560px] items-center gap-2 px-4 py-2 md:max-w-[680px] lg:hidden">
        <Link
          href={backHref}
          aria-label="Volver"
          className="grid size-10 shrink-0 place-items-center rounded-full
                     text-tq-night-ink transition-colors active:bg-tq-night-raised"
        >
          <ArrowLeft className="size-5" aria-hidden />
        </Link>

        {/* A 20px un nombre largo ya no entra en una línea. Antes que cortarlo
            con puntos suspensivos —el nombre del local es lo último que se
            recorta— pasa a dos líneas. */}
        <h1 className="min-w-0 flex-1 text-balance tq-display text-center text-[20px] uppercase leading-tight tracking-[0.03em] text-tq-night-ink">
          {nombre}
        </h1>

        {/* Contrapeso de la flecha, para que el nombre quede centrado de
            verdad y no corrido hacia la derecha. */}
        <span className="size-10 shrink-0" aria-hidden />
      </header>

      {/* ── Imagen de cabecera ───────────────────────────────────────────
          Solo en celular: en escritorio la misma foto es el hero de arriba y
          repetirla sería mostrarla dos veces. De borde a borde, sin esquinas
          redondeadas; el tope de alto evita que en una tablet la foto se coma
          la pantalla entera antes de que se vea un solo plato. */}
      {landing.menuHeaderImageUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={landing.menuHeaderImageUrl}
          alt=""
          className="aspect-[16/9] max-h-[46vh] w-full object-cover lg:hidden"
        />
      ) : null}

      {/* Una sola columna, que se ensancha con la pantalla. El tope de 920px
          en escritorio no es capricho: más ancho que eso, cada plato queda tan
          estirado que el ojo pierde de vista el precio al llegar al nombre. */}
      <div className="mx-auto w-full max-w-[560px] px-4 pb-12 pt-4 md:max-w-[680px] lg:max-w-[920px] lg:px-8 lg:pb-16 lg:pt-9">
        {/* ── Categorías y platos ──────────────────────────────────────── */}
        {conPlatos.length === 0 ? (
          <p className="py-16 text-center text-[14px] font-medium text-tq-night-muted">
            La carta todavía no está cargada.
          </p>
        ) : (
          <div className="space-y-7">
            {conPlatos.map((categoria) => (
              <Categoria
                key={categoria.id}
                categoria={categoria}
                currency={currency}
                onAmpliar={setAmpliada}
              />
            ))}
          </div>
        )}

        <p className="mt-10 text-center text-[11px] font-semibold uppercase tracking-[0.16em] text-tq-night-muted">
          Powered by <span className="text-tq-flame">Toqia</span>
        </p>
      </div>

      <Lightbox plato={ampliada} onClose={() => setAmpliada(null)} />
    </main>
  );
}

/* ── Hero (solo escritorio) ───────────────────────────────────────────────── */

/**
 * La foto del local a todo el ancho, arriba de todo.
 *
 * El degradado de abajo termina en el mismo arena del fondo: la foto no corta
 * con una línea dura, se funde con la página. Y como esa franja inferior queda
 * casi opaca, el nombre encima se lee con cualquier foto, clara u oscura, sin
 * depender de la suerte.
 *
 * Si el local no cargó imagen no se inventa un bloque de color vacío: queda
 * una cabecera simple con el nombre, que es lo único que hacía falta.
 */
function Hero({
  landing,
  nombre,
  backHref,
}: {
  landing: LandingData;
  nombre: string;
  backHref: string;
}) {
  const foto = landing.menuHeaderImageUrl;

  if (!foto) {
    return (
      <div className="mx-auto hidden w-full max-w-[1140px] px-8 pt-9 lg:block">
        <BotonVolver backHref={backHref} />
        <h1 className="tq-display mt-5 text-[38px] uppercase leading-none tracking-[0.04em] text-tq-night-ink">
          {nombre}
        </h1>
        {landing.tagline ? (
          <p className="mt-2.5 text-[15px] font-medium text-tq-night-soft">
            {landing.tagline}
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <div className="relative hidden w-full overflow-hidden lg:block lg:h-[min(42vh,420px)] lg:min-h-[320px]">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={foto}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />

      {/* Velo: transparente arriba, arena sólida abajo. */}
      <div
        aria-hidden
        className="absolute inset-0 bg-gradient-to-t from-tq-night from-[6%] via-tq-night/45 via-52% to-transparent"
      />

      <div className="relative mx-auto flex h-full max-w-[1140px] flex-col justify-between px-8 pb-8 pt-7">
        <BotonVolver backHref={backHref} sobreFoto />

        <div>
          <h1 className="tq-display text-[38px] uppercase leading-none tracking-[0.04em] text-tq-night-ink">
            {nombre}
          </h1>
          {landing.tagline ? (
            <p className="mt-2.5 text-[15px] font-semibold text-tq-night-soft">
              {landing.tagline}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function BotonVolver({
  backHref,
  sobreFoto = false,
}: {
  backHref: string;
  sobreFoto?: boolean;
}) {
  return (
    <Link
      href={backHref}
      className={
        "inline-flex w-fit items-center gap-2 text-[13px] font-semibold transition-colors " +
        (sobreFoto
          ? // Píldora blanca: sobre una foto cualquiera, un texto suelto puede
            // quedar ilegible.
            "rounded-pill bg-tq-flame px-4 py-2 text-tq-night shadow-sm hover:bg-tq-flame-light"
          : "text-tq-night-soft hover:text-tq-night-ink")
      }
    >
      <ArrowLeft className="size-4" aria-hidden />
      Volver
    </Link>
  );
}

/* ── Categoría ────────────────────────────────────────────────────────────── */

function Categoria({
  categoria,
  currency,
  onAmpliar,
}: {
  categoria: MenuCategoryRow;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  // La foto del círculo sale del primer plato con imagen de esa categoría: es
  // representativa por definición y no obliga al restaurante a cargar una foto
  // más solo para decorar.
  const portada = categoria.items.find((plato) => plato.imageUrl)?.imageUrl ?? null;

  return (
    <section>
      <div
        className={
          "tq-cat-band"
        }
      >
        {/* El ícono va antes del nombre: se reconoce de un vistazo, incluso
            antes de leer. `shrink-0` para que no se aplaste si el nombre es
            largo — el que se recorta es el texto, no el dibujo. */}
        <MenuIcon
          name={categoria.icon}
          className="mr-2.5 size-[24px] shrink-0 text-tq-night lg:size-[26px]"
        />

        <h2 className="tq-cat-title truncate">{categoria.name}</h2>

        {portada ? (
          // -right-1 hace que el círculo se salga apenas de la banda, como en
          // el diseño: rompe el rectángulo y da profundidad.
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={portada}
            alt=""
            className="absolute -right-1 top-1/2 size-[62px] -translate-y-1/2 rounded-full
                       border-[3px] border-tq-night object-cover lg:size-[72px]"
          />
        ) : null}
      </div>

      {categoria.description ? (
        <p className="mt-2.5 px-1 text-[12.5px] font-medium text-tq-night-soft">
          {categoria.description}
        </p>
      ) : null}

      {/* Dos platos por fila en escritorio: con el ancho de la columna, uno
          solo por fila deja media pantalla vacía a la derecha de cada plato. */}
      <ul className="mt-3 space-y-1.5 lg:grid lg:grid-cols-2 lg:gap-2 lg:space-y-0">
        {categoria.items.map((plato) => (
          <li key={plato.id}>
            <Plato plato={plato} currency={currency} onAmpliar={onAmpliar} />
          </li>
        ))}
      </ul>
    </section>
  );
}

/* ── Plato ────────────────────────────────────────────────────────────────── */

function Plato({
  plato,
  currency,
  onAmpliar,
}: {
  plato: MenuItemRow;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  return (
    <div className={"tq-dish " + (plato.available ? "" : "opacity-60")}>
      {/* Sin precio no se reserva el hueco: la ficha desaparece y el nombre
          se corre a la izquierda, en vez de dejar un vacío que parece un error. */}
      {plato.price ? (
        <span className="tq-price">{formatPrice(plato.price, currency)}</span>
      ) : null}

      <div className="min-w-0 flex-1">
        <h3
          className={
            "tq-dish-name " + (plato.available ? "" : "line-through")
          }
        >
          {plato.name}
        </h3>

        {plato.description ? (
          <p className="tq-dish-desc">{plato.description}</p>
        ) : null}

        {!plato.available ? (
          <p className="mt-1 text-[10.5px] font-bold uppercase tracking-[0.08em] text-tq-flame">
            Hoy no disponible
          </p>
        ) : null}
      </div>

      {plato.imageUrl ? (
        <button
          type="button"
          onClick={() => onAmpliar(plato)}
          aria-label={`Ver la foto de ${plato.name}`}
          className="shrink-0 overflow-hidden rounded-xl transition-transform duration-150
                     active:scale-95"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl}
            alt={plato.name}
            className="size-[62px] object-cover lg:size-[68px]"
          />
        </button>
      ) : null}
    </div>
  );
}

/* ── Visor de foto ampliada ───────────────────────────────────────────────── */

/**
 * Se usa `<dialog>` nativo y no un div con z-index: el navegador se encarga
 * solo del foco, de la tecla Esc y de dejar el resto de la página inerte. Eso
 * es exactamente lo que hace que funcione igual con teclado en la computadora
 * y con el dedo en el celular.
 */
function Lightbox({
  plato,
  onClose,
}: {
  plato: MenuItemRow | null;
  onClose: () => void;
}) {
  const ref = React.useRef<HTMLDialogElement>(null);

  React.useEffect(() => {
    const dialogo = ref.current;
    if (!dialogo) return;

    if (plato && !dialogo.open) dialogo.showModal();
    if (!plato && dialogo.open) dialogo.close();
  }, [plato]);

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      // Un clic en el fondo cierra. El contenido detiene la propagación para
      // que tocar la foto no la cierre sin querer.
      onClick={onClose}
      className="tq-lightbox m-0 max-h-none max-w-none bg-transparent p-0"
      style={{ width: "100vw", height: "100dvh" }}
    >
      {plato ? (
        <div
          className="flex h-full w-full flex-col items-center justify-center gap-4 p-4"
          onClick={(event) => event.stopPropagation()}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl ?? ""}
            alt={plato.name}
            className="max-h-[72vh] w-auto max-w-full rounded-2xl object-contain"
          />

          <div className="max-w-[460px] text-center">
            <p className="text-[16px] font-bold text-white">{plato.name}</p>
            {plato.description ? (
              <p className="mt-1 text-[13px] font-medium leading-snug text-white/70">
                {plato.description}
              </p>
            ) : null}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-12 items-center gap-2 rounded-pill bg-white/20 px-6
                       text-[14px] font-semibold text-white
                       transition-colors active:bg-white/30"
          >
            <X className="size-4" aria-hidden />
            Cerrar
          </button>
        </div>
      ) : null}
    </dialog>
  );
}

/* ── Auxiliares ───────────────────────────────────────────────────────────── */

/**
 * El precio llega como string desde MySQL (columna decimal) para no perder
 * centavos en el camino. Se le saca el ".00" cuando es redondo, que es como lo
 * escribe una carta de verdad.
 */
function formatPrice(price: string, currency: string): string {
  const numero = Number(price);
  if (!Number.isFinite(numero)) return `${price} ${currency}`;

  const texto = Number.isInteger(numero)
    ? String(numero)
    : numero.toFixed(2).replace(".", ",");

  return `${currency}${texto}`;
}
