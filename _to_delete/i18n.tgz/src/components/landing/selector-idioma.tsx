import { getLocale, getTranslations } from "next-intl/server";

import { cambiarIdioma } from "@/i18n/acciones";
import { IDIOMAS, NOMBRE_DE_IDIOMA, type Idioma } from "@/i18n/locales";
import { BANDERAS } from "./banderas";

/**
 * El selector de idioma de las páginas del cliente.
 *
 * Tres banderas y no un desplegable: con tres opciones, un `<select>` obliga a
 * dos toques y a leer un menú del sistema para descubrir qué hay. Acá se ve de
 * un vistazo cuál está activo y se cambia con un toque — y una bandera se
 * reconoce sin leer, que en esta página es la mitad del punto.
 *
 * El idioma activo se marca con un anillo y opacidad plena; los otros dos van
 * apagados. El color no alcanza como única señal —las tres banderas ya son de
 * colores— así que la diferencia real es el anillo.
 *
 * Es un componente de servidor: no viaja un solo byte de JavaScript de
 * traducciones al celular del cliente. El cambio es un formulario que llama a
 * una Server Action, así que funciona incluso antes de que hidrate la página.
 *
 * `volverA` es a dónde vuelve después de cambiar. En la landing tiene que
 * llevar el parámetro que saltea el registro del escaneo (ver la constante en
 * `src/app/r/[code]/page.tsx`): sin eso, cambiar de idioma pasados los 30
 * segundos de deduplicación le sumaría al local un escaneo que nunca existió.
 */
export async function SelectorIdioma({
  volverA,
  tono = "landing",
}: {
  volverA: string;
  /** "landing" = dorado sobre la portada. "carta" = champagne sobre el negro. */
  tono?: "landing" | "carta";
}) {
  const [actual, t] = await Promise.all([
    getLocale(),
    getTranslations("Idioma"),
  ]);

  const anillo =
    tono === "landing" ? "ring-2 ring-tq-gold" : "ring-2 ring-tq-champagne";
  const marco =
    tono === "landing"
      ? "border-tq-gold/45 bg-black/45"
      : "border-tq-night-line bg-tq-night-raised";

  return (
    <form action={cambiarIdioma}>
      <input type="hidden" name="volverA" value={volverA} />

      <fieldset
        className={`flex items-center gap-0.5 rounded-pill border p-0.5 ${marco}`}
      >
        <legend className="sr-only">{t("elegir")}</legend>

        {IDIOMAS.map((idioma) => {
          const esActual = idioma === (actual as Idioma);
          const Bandera = BANDERAS[idioma];

          return (
            <button
              key={idioma}
              type="submit"
              name="idioma"
              value={idioma}
              aria-current={esActual ? "true" : undefined}
              /* El nombre del idioma, no el del país: para quien no ve la
                 bandera, "English" es la información útil. */
              aria-label={NOMBRE_DE_IDIOMA[idioma]}
              /* 34px de lado: por debajo de eso el dedo empieza a errarle al
                 botón de al lado, y son tres pegados. */
              className={
                "grid size-[34px] place-items-center rounded-full transition-opacity " +
                (esActual ? `opacity-100 ${anillo}` : "opacity-45 hover:opacity-80")
              }
            >
              <Bandera />
            </button>
          );
        })}
      </fieldset>
    </form>
  );
}
