import { cookies, headers } from "next/headers";
import { getRequestConfig } from "next-intl/server";

import { COOKIE_IDIOMA, resolverIdioma } from "./locales";

/**
 * De dónde sale el idioma de cada pedido.
 *
 * **Sin routing por URL, y no es por comodidad.** El patrón habitual de
 * next-intl es `/es/...`, `/en/...` con un middleware que redirige. Acá no se
 * puede: la URL de la landing está grabada en el chip NFC
 * (`toqia.surcodes.com/r/B001`) y no lleva idioma. Meterlo en la ruta
 * obligaría a regrabar cada pulsera, que es justo lo que este sistema existe
 * para evitar. Así que el idioma sale del pedido: la cookie primero, el
 * `Accept-Language` del navegador después.
 *
 * Consecuencia a tener presente: leer cookies o headers vuelve dinámica a
 * cualquier página que use traducciones. Las que las usan
 * —`/r/[code]`, `/r/[code]/carta`, `/pulsera/*`— ya eran `force-dynamic`. Por
 * eso el provider NO va en el layout raíz: si fuera, el sitio comercial de "/"
 * dejaría de prerenderizarse estático sin ganar nada a cambio.
 */
export default getRequestConfig(async () => {
  const [cookieStore, requestHeaders] = await Promise.all([cookies(), headers()]);

  const locale = resolverIdioma(
    cookieStore.get(COOKIE_IDIOMA)?.value,
    requestHeaders.get("accept-language")
  );

  return {
    locale,
    messages: (await import(`../../messages/${locale}.json`)).default,
  };
});
