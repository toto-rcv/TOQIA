import Link from "next/link";

import { CONTACTO, SECCIONES } from "./config";
import { MarcaLink } from "./marca";

export function PieSitio() {
  return (
    <footer className="border-t border-mk-border bg-mk-bg">
      <div className="mx-auto max-w-6xl px-5 py-12 lg:px-8 lg:py-14">
        <div className="flex flex-col gap-10 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <MarcaLink />
            <p className="mt-4 max-w-xs text-[14px] leading-relaxed text-mk-muted">
              Un toque y ya. Pulseras, tarjetas y placas NFC para conectar a tus
              clientes con lo que importa de tu negocio.
            </p>
          </div>

          <nav aria-label="Pie de página">
            <ul className="flex flex-wrap gap-x-8 gap-y-3">
              {SECCIONES.map((s) => (
                <li key={s.id}>
                  <a
                    href={s.href}
                    className="text-[14px] text-mk-muted transition-colors hover:text-mk-text"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-mk-border pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[13px] text-mk-muted">
            © {new Date().getFullYear()} Toqia. Todos los derechos reservados.
          </p>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <a
              href={`mailto:${CONTACTO.email}`}
              className="text-[13px] text-mk-muted transition-colors hover:text-mk-text"
            >
              {CONTACTO.email}
            </a>
            {/* La puerta del panel. Va en el pie y no en la barra: el sitio es
                para quien todavía no es cliente; quien ya lo es entra una vez
                y lo deja en favoritos. */}
            <Link
              href="/empresa"
              className="text-[13px] text-mk-muted transition-colors hover:text-mk-text"
            >
              Acceso clientes
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
