"use client";

import Link from "next/link";
import { ArrowLeft, Info, MapPin, Search, X } from "lucide-react";
import * as React from "react";

import type { MenuCategoryRow, MenuItemRow } from "@/db/queries/menu";
import type { LandingData } from "./landing-view";

/**
 * La carta del local, tal como la ve el cliente.
 *
 * Ambiente propio, distinto de la portada negra: fondo arena, tipografía
 * redonda y bandas de color por categoría. La carta se lee sentado a la mesa,
 * con la luz de la sala; un fondo claro cansa mucho menos que texto claro
 * sobre negro, y una serif editorial hace parecer cara una milanesa.
 *
 * Jerarquía, de más a menos peso visual:
 *   categoría (banda de color) → nombre → precio → descripción → foto
 *
 * Dos formas, no una estirada:
 *
 *  - **Celular**: una columna. Cabecera con el nombre, buscador, y las
 *    categorías una debajo de la otra.
 *  - **Escritorio (≥1024px)**: dos columnas. A la izquierda, fija mientras se
 *    baja, la ficha del local con la foto, la dirección y un índice de
 *    categorías; a la derecha la carta, con los platos de a dos por fila. En
 *    una pantalla de 1440px, la columna de 520px del celular deja dos tercios
 *    de arena vacía y obliga a scrollear el triple.
 *
 * Es un componente de cliente por dos cosas que necesitan el navegador: el
 * buscador y el visor de fotos ampliadas.
 */
export function MenuView({
  landing,
  categories,
  currency,
  backHref,
}: {
  landing: LandingData;
  categories: MenuCategoryRow[];
  currency: string;
  /** A dónde vuelve el botón de atrás: siempre la página de esa pulsera. */
  backHref: string;
}) {
  const nombre = landing.displayName?.trim() || landing.name;

  const [busqueda, setBusqueda] = React.useState("");
  const [ampliada, setAmpliada] = React.useState<MenuItemRow | null>(null);

  // Una categoría sin platos visibles no aporta nada y deja un título huérfano.
  const conPlatos = React.useMemo(
    () => categories.filter((categoria) => categoria.items.length > 0),
    [categories]
  );

  const filtradas = React.useMemo(() => {
    const texto = normalizar(busqueda);
    if (texto === "") return conPlatos;

    return conPlatos
      .map((categoria) => ({
        ...categoria,
        items: categoria.items.filter(
          (plato) =>
            normalizar(plato.name).includes(texto) ||
            normalizar(plato.description ?? "").includes(texto)
        ),
      }))
      .filter((categoria) => categoria.items.length > 0);
  }, [conPlatos, busqueda]);

  const totalFiltrado = filtradas.reduce(
    (suma, categoria) => suma + categoria.items.length,
    0
  );

  return (
    <main className="tq-menu-page tq-menu">
      {/* El hero va fuera del contenedor centrado para poder ocupar todo el
          ancho de la ventana, de borde a borde. */}
      <Hero landing={landing} nombre={nombre} backHref={backHref} />

      <div
        // En tablet no hay dos columnas (la lateral de 304px dejaría la carta
        // muy angosta), pero sí una columna más ancha: 560px centrados en 834
        // se ven como una tira flaca rodeada de arena.
        className="mx-auto w-full max-w-[560px] px-4 pb-12 pt-3 md:max-w-[680px] md:pt-6 lg:max-w-[1140px] lg:px-8 lg:pb-16 lg:pt-9"
      >
        <div className="lg:grid lg:grid-cols-[304px_minmax(0,1fr)] lg:items-start lg:gap-10">
          <Ficha landing={landing} categorias={filtradas} />

          <div>
        {/* ── Cabecera (celular) ───────────────────────────────────────── */}
        <header className="flex items-center gap-2 py-2 lg:hidden">
          <Link
            href={backHref}
            aria-label="Volver"
            className="grid size-10 shrink-0 place-items-center rounded-full
                       text-tq-sand-ink transition-colors active:bg-tq-sand-deep"
          >
            <ArrowLeft className="size-5" aria-hidden />
          </Link>

          <h1 className="min-w-0 flex-1 truncate text-center text-[15px] font-extrabold uppercase tracking-[0.1em] text-tq-sand-ink">
            {nombre}
          </h1>

          {landing.address ? (
            <a
              href={backHref}
              aria-label="Volver a la página del local"
              title={landing.address}
              className="grid size-10 shrink-0 place-items-center rounded-full
                         text-tq-sand-soft transition-colors active:bg-tq-sand-deep"
            >
              <Info className="size-5" aria-hidden />
            </a>
          ) : (
            <span className="size-10 shrink-0" aria-hidden />
          )}
        </header>

        {/* ── Buscador ─────────────────────────────────────────────────
            Solo en celular y tablet. En escritorio la carta entera entra en
            pantalla y el índice de la izquierda lleva a cualquier categoría en
            un clic: un campo de búsqueda ahí es un control de más. */}
        <div className="relative mt-1 lg:hidden">
          <Search
            className="pointer-events-none absolute left-4 top-1/2 size-[18px] -translate-y-1/2 text-tq-sand-muted"
            aria-hidden
          />
          <input
            type="search"
            value={busqueda}
            onChange={(event) => setBusqueda(event.target.value)}
            placeholder="Buscar en la carta…"
            aria-label="Buscar en la carta"
            className="h-12 w-full rounded-pill border border-tq-sand-line bg-tq-sand-card
                       pl-11 pr-10 text-[14px] font-medium text-tq-sand-ink
                       placeholder:text-tq-sand-muted focus:border-tq-terracotta
                       focus:outline-none focus:ring-4 focus:ring-tq-terracotta/12
                       [&::-webkit-search-cancel-button]:hidden"
          />
          {busqueda ? (
            <button
              type="button"
              onClick={() => setBusqueda("")}
              aria-label="Borrar la búsqueda"
              className="absolute right-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center
                         rounded-full text-tq-sand-soft"
            >
              <X className="size-4" aria-hidden />
            </button>
          ) : null}
        </div>

        {/* ── Imagen de cabecera ───────────────────────────────────────
            Solo en celular: en escritorio la misma foto es el hero de arriba y
            repetirla sería mostrarla dos veces. */}
        {landing.menuHeaderImageUrl && busqueda === "" ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={landing.menuHeaderImageUrl}
            alt=""
            className="mt-4 aspect-[16/9] w-full rounded-3xl object-cover lg:hidden"
          />
        ) : null}

        {/* ── Categorías y platos ──────────────────────────────────────── */}
        {conPlatos.length === 0 ? (
          <p className="py-16 text-center text-[14px] font-medium text-tq-sand-muted">
            La carta todavía no está cargada.
          </p>
        ) : totalFiltrado === 0 ? (
          <p className="py-16 text-center text-[14px] font-medium text-tq-sand-muted">
            No encontramos nada con “{busqueda}”.
          </p>
        ) : (
          <div className="mt-5 space-y-7">
            {filtradas.map((categoria, indice) => (
              <Categoria
                key={categoria.id}
                categoria={categoria}
                indice={indice}
                currency={currency}
                onAmpliar={setAmpliada}
              />
            ))}
          </div>
        )}

        <p className="mt-10 text-center text-[11px] font-semibold uppercase tracking-[0.16em] text-tq-sand-muted lg:text-left">
          Powered by <span className="text-tq-sand-soft">Toqia</span>
        </p>
          </div>
        </div>
      </div>

      <Lightbox plato={ampliada} onClose={() => setAmpliada(null)} />
    </main>
  );
}

/* ── Hero (solo escritorio) ───────────────────────────────────────────────── */

/**
 * La foto del local a todo el ancho, arriba de todo.
 *
 * El degradado de abajo termina en el mismo arena del fondo: la foto no corta
 * con una línea dura, se funde con la página. Y como esa franja inferior queda
 * casi opaca, el nombre encima se lee con cualquier foto, clara u oscura, sin
 * depender de la suerte.
 *
 * Si el local no cargó imagen no se inventa un bloque de color vacío: queda
 * una cabecera simple con el nombre, que es lo único que hacía falta.
 */
function Hero({
  landing,
  nombre,
  backHref,
}: {
  landing: LandingData;
  nombre: string;
  backHref: string;
}) {
  const foto = landing.menuHeaderImageUrl;

  if (!foto) {
    return (
      <div className="mx-auto hidden w-full max-w-[1140px] px-8 pt-9 lg:block">
        <BotonVolver backHref={backHref} />
        <h1 className="mt-5 text-[38px] font-extrabold uppercase leading-none tracking-[0.05em] text-tq-sand-ink">
          {nombre}
        </h1>
        {landing.tagline ? (
          <p className="mt-2.5 text-[15px] font-medium text-tq-sand-soft">
            {landing.tagline}
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <div className="relative hidden w-full overflow-hidden lg:block lg:h-[min(42vh,420px)] lg:min-h-[320px]">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={foto}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />

      {/* Velo: transparente arriba, arena sólida abajo. */}
      <div
        aria-hidden
        className="absolute inset-0 bg-gradient-to-t from-tq-sand from-[6%] via-tq-sand/30 via-52% to-transparent"
      />

      <div className="relative mx-auto flex h-full max-w-[1140px] flex-col justify-between px-8 pb-8 pt-7">
        <BotonVolver backHref={backHref} sobreFoto />

        <div>
          <h1 className="text-[38px] font-extrabold uppercase leading-none tracking-[0.05em] text-tq-sand-ink">
            {nombre}
          </h1>
          {landing.tagline ? (
            <p className="mt-2.5 text-[15px] font-semibold text-tq-sand-soft">
              {landing.tagline}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function BotonVolver({
  backHref,
  sobreFoto = false,
}: {
  backHref: string;
  sobreFoto?: boolean;
}) {
  return (
    <Link
      href={backHref}
      className={
        "inline-flex w-fit items-center gap-2 text-[13px] font-semibold transition-colors " +
        (sobreFoto
          ? // Píldora blanca: sobre una foto cualquiera, un texto suelto puede
            // quedar ilegible.
            "rounded-pill bg-white/90 px-4 py-2 text-tq-sand-ink shadow-sm backdrop-blur hover:bg-white"
          : "text-tq-sand-soft hover:text-tq-sand-ink")
      }
    >
      <ArrowLeft className="size-4" aria-hidden />
      Volver
    </Link>
  );
}

/* ── Ficha del local (solo escritorio) ────────────────────────────────────── */

/**
 * La columna de la izquierda: queda fija mientras se baja por la carta.
 *
 * Cumple dos funciones que en el celular resuelve el scroll: recuerda en qué
 * local estás, y deja saltar a una categoría sin recorrer toda la carta. En
 * una carta de sesenta platos, eso es la diferencia entre buscar el postre y
 * rendirse.
 */
function Ficha({
  landing,
  categorias,
}: {
  landing: LandingData;
  categorias: MenuCategoryRow[];
}) {
  // El nombre, la frase y el botón de volver viven en el hero. Acá queda lo
  // que sirve mientras se baja por la carta: dónde queda el local y el índice.
  if (!landing.address && categorias.length <= 1) return <div className="hidden lg:block" />;

  return (
    <aside className="hidden lg:sticky lg:top-8 lg:block">
      {landing.address ? (
        <p className="flex items-start gap-2 text-[12.5px] font-medium leading-snug text-tq-sand-muted">
          <MapPin className="mt-px size-4 shrink-0" aria-hidden />
          {landing.address}
        </p>
      ) : null}

      {categorias.length > 1 ? (
        <nav
          className={
            (landing.address ? "mt-5 border-t border-tq-sand-line pt-5" : "") +
            " "
          }
          aria-label="Categorías"
        >
          <p className="mb-2.5 text-[11px] font-bold uppercase tracking-[0.12em] text-tq-sand-muted">
            La carta
          </p>
          <ul className="space-y-0.5">
            {categorias.map((categoria) => (
              <li key={categoria.id}>
                <a
                  href={`#cat-${categoria.id}`}
                  className="flex items-center justify-between gap-3 rounded-xl px-3 py-2
                             text-[13.5px] font-semibold text-tq-sand-ink transition-colors
                             hover:bg-tq-sand-card"
                >
                  <span className="truncate">{categoria.name}</span>
                  <span className="shrink-0 text-[12px] font-medium tabular-nums text-tq-sand-muted">
                    {categoria.items.length}
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      ) : null}
    </aside>
  );
}

/* ── Categoría ────────────────────────────────────────────────────────────── */

function Categoria({
  categoria,
  indice,
  currency,
  onAmpliar,
}: {
  categoria: MenuCategoryRow;
  indice: number;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  // Alterna terracota y café para que dos bandas seguidas no se confundan.
  const oscura = indice % 2 === 1;

  // La foto del círculo sale del primer plato con imagen de esa categoría: es
  // representativa por definición y no obliga al restaurante a cargar una foto
  // más solo para decorar.
  const portada = categoria.items.find((plato) => plato.imageUrl)?.imageUrl ?? null;

  return (
    // scroll-mt deja aire arriba al saltar desde el índice: sin eso la banda
    // queda pegada al borde de la ventana y no se ve dónde empieza.
    <section id={`cat-${categoria.id}`} className="scroll-mt-8">
      <div
        className={
          "tq-cat-band " + (oscura ? "bg-tq-espresso" : "bg-tq-terracotta")
        }
      >
        <h2 className="tq-cat-title truncate">{categoria.name}</h2>

        {portada ? (
          // -right-1 hace que el círculo se salga apenas de la banda, como en
          // el diseño: rompe el rectángulo y da profundidad.
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={portada}
            alt=""
            className="absolute -right-1 top-1/2 size-[62px] -translate-y-1/2 rounded-full
                       border-[3px] border-tq-sand object-cover lg:size-[72px]"
          />
        ) : null}
      </div>

      {categoria.description ? (
        <p className="mt-2.5 px-1 text-[12.5px] font-medium text-tq-sand-soft">
          {categoria.description}
        </p>
      ) : null}

      {/* Dos platos por fila en escritorio: con el ancho de la columna, uno
          solo por fila deja media pantalla vacía a la derecha de cada plato. */}
      <ul className="mt-3 space-y-1.5 lg:grid lg:grid-cols-2 lg:gap-2 lg:space-y-0">
        {categoria.items.map((plato) => (
          <li key={plato.id}>
            <Plato plato={plato} currency={currency} onAmpliar={onAmpliar} />
          </li>
        ))}
      </ul>
    </section>
  );
}

/* ── Plato ────────────────────────────────────────────────────────────────── */

function Plato({
  plato,
  currency,
  onAmpliar,
}: {
  plato: MenuItemRow;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  return (
    <div className={"tq-dish " + (plato.available ? "" : "opacity-60")}>
      {/* Sin precio no se reserva el hueco: la ficha desaparece y el nombre
          se corre a la izquierda, en vez de dejar un vacío que parece un error. */}
      {plato.price ? (
        <span className="tq-price">{formatPrice(plato.price, currency)}</span>
      ) : null}

      <div className="min-w-0 flex-1">
        <h3
          className={
            "tq-dish-name " + (plato.available ? "" : "line-through")
          }
        >
          {plato.name}
        </h3>

        {plato.description ? (
          <p className="tq-dish-desc">{plato.description}</p>
        ) : null}

        {!plato.available ? (
          <p className="mt-1 text-[10.5px] font-bold uppercase tracking-[0.08em] text-tq-terracotta">
            Hoy no disponible
          </p>
        ) : null}
      </div>

      {plato.imageUrl ? (
        <button
          type="button"
          onClick={() => onAmpliar(plato)}
          aria-label={`Ver la foto de ${plato.name}`}
          className="shrink-0 overflow-hidden rounded-xl transition-transform duration-150
                     active:scale-95"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl}
            alt={plato.name}
            className="size-[62px] object-cover lg:size-[68px]"
          />
        </button>
      ) : null}
    </div>
  );
}

/* ── Visor de foto ampliada ───────────────────────────────────────────────── */

/**
 * Se usa `<dialog>` nativo y no un div con z-index: el navegador se encarga
 * solo del foco, de la tecla Esc y de dejar el resto de la página inerte. Eso
 * es exactamente lo que hace que funcione igual con teclado en la computadora
 * y con el dedo en el celular.
 */
function Lightbox({
  plato,
  onClose,
}: {
  plato: MenuItemRow | null;
  onClose: () => void;
}) {
  const ref = React.useRef<HTMLDialogElement>(null);

  React.useEffect(() => {
    const dialogo = ref.current;
    if (!dialogo) return;

    if (plato && !dialogo.open) dialogo.showModal();
    if (!plato && dialogo.open) dialogo.close();
  }, [plato]);

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      // Un clic en el fondo cierra. El contenido detiene la propagación para
      // que tocar la foto no la cierre sin querer.
      onClick={onClose}
      className="tq-lightbox m-0 max-h-none max-w-none bg-transparent p-0"
      style={{ width: "100vw", height: "100dvh" }}
    >
      {plato ? (
        <div
          className="flex h-full w-full flex-col items-center justify-center gap-4 p-4"
          onClick={(event) => event.stopPropagation()}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl ?? ""}
            alt={plato.name}
            className="max-h-[72vh] w-auto max-w-full rounded-2xl object-contain"
          />

          <div className="max-w-[460px] text-center">
            <p className="text-[16px] font-bold text-white">{plato.name}</p>
            {plato.description ? (
              <p className="mt-1 text-[13px] font-medium leading-snug text-white/70">
                {plato.description}
              </p>
            ) : null}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-12 items-center gap-2 rounded-pill bg-white/20 px-6
                       text-[14px] font-semibold text-white
                       transition-colors active:bg-white/30"
          >
            <X className="size-4" aria-hidden />
            Cerrar
          </button>
        </div>
      ) : null}
    </dialog>
  );
}

/* ── Auxiliares ───────────────────────────────────────────────────────────── */

/**
 * El precio llega como string desde MySQL (columna decimal) para no perder
 * centavos en el camino. Se le saca el ".00" cuando es redondo, que es como lo
 * escribe una carta de verdad.
 */
function formatPrice(price: string, currency: string): string {
  const numero = Number(price);
  if (!Number.isFinite(numero)) return `${price} ${currency}`;

  const texto = Number.isInteger(numero)
    ? String(numero)
    : numero.toFixed(2).replace(".", ",");

  return `${currency}${texto}`;
}

/** Para buscar sin que las tildes ni las mayúsculas estorben. */
function normalizar(texto: string): string {
  return texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}
