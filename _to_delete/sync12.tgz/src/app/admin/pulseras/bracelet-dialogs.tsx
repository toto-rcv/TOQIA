"use client";

import { Layers, Plus, Power, Settings2 } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogBody,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input, Label, Select } from "@/components/ui/input";
import type { BraceletListItem } from "@/db/queries/bracelets";
import {
  createBracelet,
  createBraceletsBulk,
  toggleBracelet,
  updateBracelet,
} from "../actions";

type LocationOption = { id: number; name: string; accountName: string };
type WaiterOption = { id: number; name: string; locationId: number; active: boolean };
type DistributorOption = { id: string; name: string; email: string };

/* ── Destino ─────────────────────────────────────────────────────────────── */

/**
 * Dónde está la pulsera: en un local, en el stock de un distribuidor, o en el
 * de Toqia.
 *
 * Es un solo desplegable y no dos campos excluyentes: así no existe el estado
 * imposible de "en un local y en un stock a la vez", y el recorrido físico
 * Toqia → distribuidor → local se lee de arriba hacia abajo en la lista.
 */
const DESTINO_STOCK = "stock";

function valorDeDestino(
  locationId: number | null,
  distributorId: string | null
): string {
  if (locationId) return `local:${locationId}`;
  if (distributorId) return `distribuidor:${distributorId}`;
  return DESTINO_STOCK;
}

/** El local elegido, o null si el destino es un stock. */
function localDeDestino(destino: string): number | null {
  return destino.startsWith("local:")
    ? Number(destino.slice("local:".length))
    : null;
}

function DestinoSelect({
  id,
  locations,
  distributors,
  value,
  onChange,
}: {
  id: string;
  locations: LocationOption[];
  distributors: DistributorOption[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>Destino</Label>
      <Select id={id} name="destino" value={value} onChange={(e) => onChange(e.target.value)}>
        <optgroup label="Sin colocar">
          <option value={DESTINO_STOCK}>Stock de Toqia</option>
          {distributors.map((distribuidor) => (
            <option key={distribuidor.id} value={`distribuidor:${distribuidor.id}`}>
              Stock de {distribuidor.name}
            </option>
          ))}
        </optgroup>
        <optgroup label="En un local">
          {locations.map((local) => (
            <option key={local.id} value={`local:${local.id}`}>
              {local.accountName} · {local.name}
            </option>
          ))}
        </optgroup>
      </Select>
    </div>
  );
}

/* ── Alta individual ─────────────────────────────────────────────────────── */

export function NewBraceletDialog({
  locations,
  distributors,
  defaultLocationId,
}: {
  locations: LocationOption[];
  distributors: DistributorOption[];
  defaultLocationId?: number;
}) {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();
  const formRef = React.useRef<HTMLFormElement>(null);
  const [destino, setDestino] = React.useState(
    defaultLocationId ? `local:${defaultLocationId}` : DESTINO_STOCK
  );

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setError(null);

    startTransition(async () => {
      const resultado = await createBracelet(formData);
      if (!resultado.ok) {
        setError(resultado.error);
        return;
      }
      formRef.current?.reset();
      setOpen(false);
    });
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button variant="secondary" size="sm" onClick={() => setOpen(true)}>
        <Plus />
        Nueva pulsera
      </Button>

      <DialogContent>
        <form ref={formRef} onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Nueva pulsera</DialogTitle>
            <DialogDescription>
              El código es el que se graba en el chip y no se puede repetir en
              todo el sistema.
            </DialogDescription>
          </DialogHeader>

          <DialogBody className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="b-code">Código</Label>
                <Input
                  id="b-code"
                  name="code"
                  required
                  placeholder="B001"
                  spellCheck={false}
                  className="font-mono"
                />
              </div>
              <DestinoSelect
                id="b-destino"
                locations={locations}
                distributors={distributors}
                value={destino}
                onChange={setDestino}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="b-type">Tipo</Label>
                <Select id="b-type" name="deviceType" defaultValue="pulsera">
                  <option value="pulsera">Pulsera</option>
                  <option value="placa">Placa</option>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="b-label">
                  Etiqueta <span className="text-ex-text-disabled">(opcional)</span>
                </Label>
                <Input id="b-label" name="label" placeholder="Mesa 4, Barra…" />
              </div>
            </div>

            <OverrideField id="b-override" />

            {error ? <ErrorBox message={error} /> : null}
          </DialogBody>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={pending}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" disabled={pending}>
              {pending ? "Creando…" : "Crear"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ── Alta masiva ─────────────────────────────────────────────────────────── */

export function BulkCreateDialog({
  locations,
  distributors,
  defaultLocationId,
}: {
  locations: LocationOption[];
  distributors: DistributorOption[];
  defaultLocationId?: number;
}) {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [resumen, setResumen] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();

  // Preview en vivo del rango: evita generar veinte pulseras mal nombradas.
  const [prefix, setPrefix] = React.useState("B");
  const [start, setStart] = React.useState(1);
  const [count, setCount] = React.useState(20);
  const [padding, setPadding] = React.useState(3);
  const [destino, setDestino] = React.useState(
    defaultLocationId ? `local:${defaultLocationId}` : DESTINO_STOCK
  );

  const preview = React.useMemo(() => {
    if (count < 1) return "—";
    const primero = `${prefix}${String(start).padStart(padding, "0")}`;
    if (count === 1) return primero;
    const ultimo = `${prefix}${String(start + count - 1).padStart(padding, "0")}`;
    return `${primero} → ${ultimo}`;
  }, [prefix, start, count, padding]);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setError(null);
    setResumen(null);

    startTransition(async () => {
      const resultado = await createBraceletsBulk(formData);
      if (!resultado.ok) {
        setError(resultado.error);
        return;
      }

      const data = resultado.data;
      if (data && data.skipped.length > 0) {
        // No cerramos: el usuario tiene que ver qué se salteó.
        setResumen(
          `Se crearon ${data.created} pulseras. Se saltearon ${data.skipped.length} porque ya existían: ${data.skipped.slice(0, 8).join(", ")}${data.skipped.length > 8 ? "…" : ""}`
        );
        return;
      }

      setOpen(false);
    });
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) {
          setError(null);
          setResumen(null);
        }
      }}
    >
      <Button variant="primary" size="sm" onClick={() => setOpen(true)}>
        <Layers />
        Alta masiva
      </Button>

      <DialogContent>
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Generar lote de pulseras</DialogTitle>
            <DialogDescription>
              Los códigos que ya existan se saltean.
            </DialogDescription>
          </DialogHeader>

          <DialogBody className="space-y-4">
            <DestinoSelect
              id="bulk-destino"
              locations={locations}
              distributors={distributors}
              value={destino}
              onChange={setDestino}
            />

            <div className="space-y-1.5">
              <Label htmlFor="bulk-type">Tipo de dispositivo</Label>
              <Select id="bulk-type" name="deviceType" defaultValue="pulsera">
                <option value="pulsera">Pulseras</option>
                <option value="placa">Placas</option>
              </Select>
            </div>

            <div className="grid grid-cols-4 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="bulk-prefix">Prefijo</Label>
                <Input
                  id="bulk-prefix"
                  name="prefix"
                  value={prefix}
                  onChange={(event) => setPrefix(event.target.value)}
                  required
                  spellCheck={false}
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bulk-start">Desde</Label>
                <Input
                  id="bulk-start"
                  name="start"
                  type="number"
                  min={0}
                  value={start}
                  onChange={(event) => setStart(Number(event.target.value))}
                  required
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bulk-count">Cantidad</Label>
                <Input
                  id="bulk-count"
                  name="count"
                  type="number"
                  min={1}
                  max={500}
                  value={count}
                  onChange={(event) => setCount(Number(event.target.value))}
                  required
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bulk-padding">Dígitos</Label>
                <Input
                  id="bulk-padding"
                  name="padding"
                  type="number"
                  min={0}
                  max={10}
                  value={padding}
                  onChange={(event) => setPadding(Number(event.target.value))}
                  required
                  className="font-mono"
                />
              </div>
            </div>

            <div className="rounded-control border border-ex-border bg-ex-black px-3 py-2">
              <p className="ex-label mb-1">Se van a generar</p>
              <p className="font-mono text-sm text-ex-blue-bright">{preview}</p>
            </div>

            {error ? <ErrorBox message={error} /> : null}
            {resumen ? (
              <p className="rounded-control border border-ex-warning/25 bg-ex-warning/10 px-3 py-2 text-xs text-ex-warning">
                {resumen}
              </p>
            ) : null}
          </DialogBody>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={pending}>
              {resumen ? "Cerrar" : "Cancelar"}
            </Button>
            <Button type="submit" variant="primary" disabled={pending}>
              {pending ? "Generando…" : "Generar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ── Acciones de fila ────────────────────────────────────────────────────── */

export function BraceletRowActions({
  bracelet,
  locations,
  distributors,
  waiters,
}: {
  bracelet: BraceletListItem;
  locations: LocationOption[];
  distributors: DistributorOption[];
  waiters: WaiterOption[];
}) {
  return (
    <div className="flex items-center justify-end gap-1.5">
      <EditBraceletDialog
        bracelet={bracelet}
        locations={locations}
        distributors={distributors}
        waiters={waiters}
      />
      <ToggleBraceletButton bracelet={bracelet} />
    </div>
  );
}

function EditBraceletDialog({
  bracelet,
  locations,
  distributors,
  waiters,
}: {
  bracelet: BraceletListItem;
  locations: LocationOption[];
  distributors: DistributorOption[];
  waiters: WaiterOption[];
}) {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();
  const [destino, setDestino] = React.useState(
    valorDeDestino(bracelet.locationId, bracelet.distributorId)
  );

  // Un camarero solo puede tener pulseras de su propio local, así que la lista
  // se filtra por el local elegido en este mismo formulario. Si el destino es
  // un stock no hay local, y no hay camareros para elegir.
  const localElegido = localDeDestino(destino);
  const camarerosDelLocal =
    localElegido === null
      ? []
      : waiters.filter((camarero) => camarero.locationId === localElegido);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setError(null);

    startTransition(async () => {
      const resultado = await updateBracelet(formData);
      if (!resultado.ok) {
        setError(resultado.error);
        return;
      }
      setOpen(false);
    });
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <button
        type="button"
        onClick={() => setOpen(true)}
        title="Editar pulsera"
        aria-label="Editar pulsera"
        className="inline-flex h-7 w-7 items-center justify-center rounded-control border
                   border-ex-border text-ex-text-muted transition-colors
                   hover:border-ex-blue/40 hover:text-ex-text active:scale-[0.98]"
      >
        <Settings2 className="size-3.5" />
      </button>

      <DialogContent>
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Editar pulsera {bracelet.code}</DialogTitle>
            <DialogDescription>
              Cambiar el código obliga a regrabar el chip.
            </DialogDescription>
          </DialogHeader>

          <DialogBody className="space-y-4">
            <input type="hidden" name="id" value={bracelet.id} />

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor={`e-code-${bracelet.id}`}>Código</Label>
                <Input
                  id={`e-code-${bracelet.id}`}
                  name="code"
                  defaultValue={bracelet.code}
                  required
                  spellCheck={false}
                  className="font-mono"
                />
              </div>
              <DestinoSelect
                id={`e-destino-${bracelet.id}`}
                locations={locations}
                distributors={distributors}
                value={destino}
                onChange={setDestino}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor={`e-waiter-${bracelet.id}`}>Camarero</Label>
                <Select
                  id={`e-waiter-${bracelet.id}`}
                  name="waiterId"
                  defaultValue={bracelet.waiterId ? String(bracelet.waiterId) : ""}
                  disabled={localElegido === null}
                >
                  <option value="">Sin asignar</option>
                  {camarerosDelLocal.map((camarero) => (
                    <option key={camarero.id} value={camarero.id}>
                      {camarero.name}
                      {camarero.active ? "" : " (inactivo)"}
                    </option>
                  ))}
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`e-label-${bracelet.id}`}>Etiqueta</Label>
                <Input
                  id={`e-label-${bracelet.id}`}
                  name="label"
                  defaultValue={bracelet.label ?? ""}
                  placeholder="Mesa 4, Barra…"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor={`e-type-${bracelet.id}`}>Tipo de dispositivo</Label>
              <Select
                id={`e-type-${bracelet.id}`}
                name="deviceType"
                defaultValue={bracelet.deviceType}
              >
                <option value="pulsera">Pulsera</option>
                <option value="placa">Placa</option>
              </Select>
            </div>

            <OverrideField
              id={`e-override-${bracelet.id}`}
              defaultValue={bracelet.overrideUrl ?? ""}
            />

            {error ? <ErrorBox message={error} /> : null}
          </DialogBody>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={pending}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" disabled={pending}>
              {pending ? "Guardando…" : "Guardar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ToggleBraceletButton({ bracelet }: { bracelet: BraceletListItem }) {
  const [pending, startTransition] = React.useTransition();
  const [error, setError] = React.useState<string | null>(null);

  function handleClick() {
    setError(null);
    startTransition(async () => {
      const resultado = await toggleBracelet(bracelet.id, !bracelet.active);
      if (!resultado.ok) setError(resultado.error);
    });
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={pending}
      title={error ?? (bracelet.active ? "Desactivar pulsera" : "Activar pulsera")}
      aria-label={bracelet.active ? "Desactivar pulsera" : "Activar pulsera"}
      className={
        "inline-flex h-7 w-7 items-center justify-center rounded-control border transition-colors " +
        "active:scale-[0.98] disabled:opacity-40 " +
        (error
          ? "border-ex-danger/40 text-ex-danger"
          : bracelet.active
            ? "border-ex-border text-ex-text-muted hover:border-ex-danger/40 hover:text-ex-danger"
            : "border-ex-border text-ex-text-muted hover:border-ex-success/40 hover:text-ex-success")
      }
    >
      <Power className="size-3.5" />
    </button>
  );
}

function OverrideField({
  id,
  defaultValue = "",
}: {
  id: string;
  defaultValue?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>
        Destino directo <span className="text-ex-text-disabled">(opcional)</span>
      </Label>
      <Input
        id={id}
        name="overrideUrl"
        defaultValue={defaultValue}
        spellCheck={false}
        placeholder="https://…"
        className="font-mono text-xs"
      />
      <p className="text-[11px] text-ex-text-muted">
        Si lo cargás, esta pulsera saltea la página del local y va directo acá.
        El escaneo se registra igual.
      </p>
    </div>
  );
}

function ErrorBox({ message }: { message: string }) {
  return (
    <p
      role="alert"
      className="rounded-control border border-ex-danger/25 bg-ex-danger/10 px-3 py-2 text-xs text-ex-danger"
    >
      {message}
    </p>
  );
}
