import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import type { MenuCategoryRow } from "@/db/queries/menu";
import { LandingHeader, type LandingData } from "./landing-view";

/**
 * La carta del local, tal como la ve el cliente.
 *
 * Comparte la portada con la landing para que se sienta la misma página y no
 * un sitio distinto. Los platos sin foto no dejan un hueco: la fila se arma
 * igual, solo con nombre, descripción y precio.
 */
export function MenuView({
  landing,
  categories,
  currency,
  backHref,
}: {
  landing: LandingData;
  categories: MenuCategoryRow[];
  currency: string;
  /** A dónde vuelve el botón de atrás: siempre la página de esa pulsera. */
  backHref: string;
}) {
  const nombre = landing.displayName?.trim() || landing.name;

  // Una categoría sin platos visibles no aporta nada y deja un título huérfano.
  const conPlatos = categories.filter((categoria) => categoria.items.length > 0);

  return (
    <main className="tq-page">
      <div className="mx-auto w-full max-w-[460px]">
        <LandingHeader landing={landing} nombre={nombre} />

        <div className="relative -mt-10 min-h-[60vh] rounded-t-[28px] bg-tq-cream px-5 pb-10 pt-7">
          <Link
            href={backHref}
            className="mb-6 inline-flex items-center gap-2 text-[13px] text-tq-ink-soft
                       transition-colors hover:text-tq-ink"
          >
            <ArrowLeft className="size-4" aria-hidden />
            Volver
          </Link>

          {landing.menuHeaderImageUrl ? (
            // Imagen que elige el local para encabezar su carta. Va en 16:9
            // recortada: así una foto vertical o cuadrada no empuja toda la
            // carta abajo del pliegue.
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={landing.menuHeaderImageUrl}
              alt=""
              className="mb-6 aspect-[16/9] w-full rounded-2xl object-cover"
            />
          ) : null}

          <h1 className="mb-1 text-center font-serif text-[28px] text-tq-ink">
            Nuestra carta
          </h1>
          <p className="mb-8 text-center text-[12px] uppercase tracking-[0.18em] text-tq-gold">
            {nombre}
          </p>

          {conPlatos.length === 0 ? (
            <p className="py-12 text-center text-sm text-tq-muted">
              La carta todavía no está cargada.
            </p>
          ) : (
            <div className="space-y-9">
              {conPlatos.map((categoria) => (
                <section key={categoria.id}>
                  <h2 className="tq-rule mb-1 text-[13px] font-semibold uppercase tracking-[0.14em]">
                    {categoria.name}
                  </h2>

                  {categoria.description ? (
                    <p className="mb-4 mt-2 text-center text-[12px] text-tq-muted">
                      {categoria.description}
                    </p>
                  ) : (
                    <div className="h-4" />
                  )}

                  <ul className="space-y-3">
                    {categoria.items.map((plato) => (
                      <li
                        key={plato.id}
                        className="flex gap-3 rounded-xl border border-tq-cream-border bg-tq-cream-alt p-3"
                      >
                        {plato.imageUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={plato.imageUrl}
                            alt=""
                            className="size-[72px] shrink-0 rounded-lg object-cover"
                          />
                        ) : null}

                        <div className="min-w-0 flex-1">
                          <div className="flex items-baseline justify-between gap-3">
                            <h3
                              className={
                                "text-[15px] font-semibold text-tq-ink" +
                                // Sin stock: se muestra tachado en vez de
                                // desaparecer, así el cliente sabe que existe.
                                (plato.available ? "" : " line-through opacity-55")
                              }
                            >
                              {plato.name}
                            </h3>

                            {plato.price ? (
                              <span className="shrink-0 font-mono text-[14px] font-semibold text-tq-ink">
                                {formatPrice(plato.price, currency)}
                              </span>
                            ) : null}
                          </div>

                          {plato.description ? (
                            <p className="mt-1 text-[13px] leading-snug text-tq-ink-soft">
                              {plato.description}
                            </p>
                          ) : null}

                          {!plato.available ? (
                            <p className="mt-1.5 text-[11px] uppercase tracking-[0.1em] text-tq-muted">
                              Hoy no disponible
                            </p>
                          ) : null}
                        </div>
                      </li>
                    ))}
                  </ul>
                </section>
              ))}
            </div>
          )}

          <p className="mt-10 text-center text-[11px] tracking-[0.14em] text-tq-muted">
            POWERED BY{" "}
            <span className="font-semibold tracking-[0.18em] text-tq-ink">TOQIA</span>
          </p>
        </div>
      </div>
    </main>
  );
}

/**
 * El precio llega como string desde MySQL (columna decimal) para no perder
 * centavos en el camino. Se le saca el ".00" cuando es redondo, que es como lo
 * escribe una carta de verdad.
 */
function formatPrice(price: string, currency: string): string {
  const numero = Number(price);
  if (!Number.isFinite(numero)) return `${price} ${currency}`;

  const texto = Number.isInteger(numero)
    ? String(numero)
    : numero.toFixed(2).replace(".", ",");

  return `${texto} ${currency}`;
}
