import type { Metadata, Viewport } from "next";
import { GeistMono } from "geist/font/mono";
import { GeistSans } from "geist/font/sans";

import "./globals.css";

export const metadata: Metadata = {
  title: "Pulseras NFC",
  description: "Sistema de captación de reseñas de Google mediante pulseras NFC.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  // El endpoint se abre casi siempre desde un celular.
  themeColor: "#070A0F",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      {/* Varias extensiones de Chrome (ColorZilla, gestores de contraseñas,
          traductores) le agregan atributos al <body> antes de que React
          hidrate, y React lo reporta como un error de hidratación que no es
          culpa de la app y que el usuario no puede arreglar. Esto silencia la
          comparación en este nodo puntual, no en el resto del árbol. */}
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
