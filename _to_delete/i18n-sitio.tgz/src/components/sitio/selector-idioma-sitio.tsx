import { getLocale, getTranslations } from "next-intl/server";

import { BANDERAS } from "@/components/ui/banderas";
import { inicioDelSitio } from "@/i18n/rutas";
import { IDIOMAS, NOMBRE_DE_IDIOMA, type Idioma } from "@/i18n/locales";

/**
 * El selector de idioma del sitio comercial.
 *
 * Distinto del de la landing, y por un motivo concreto: acá el idioma vive en
 * la URL (`/`, `/en`, `/it`), así que cambiarlo es **navegar**, no guardar una
 * preferencia. Son tres enlaces a la misma página en otro idioma, que es
 * además lo que Google espera encontrar para entender que las tres URLs son la
 * misma página.
 *
 * Son `<a>` y no `<Link>`: cambiar de idioma cambia el documento entero
 * —incluido el `lang` del `<html>`— así que una carga completa es lo correcto,
 * y de paso evita montar el proveedor de next-intl en el navegador solo para
 * resolver tres direcciones que el servidor ya conoce.
 *
 * El middleware, al resolver el idioma del pedido, deja la elección en la
 * misma cookie que usan la landing y la carta. Por eso alguien que pone
 * italiano acá y después escanea una pulsera la ve en italiano.
 */
export async function SelectorIdiomaSitio({
  className,
}: {
  className?: string;
}) {
  const [actual, t] = await Promise.all([getLocale(), getTranslations("Idioma")]);

  return (
    <nav
      aria-label={t("elegir")}
      className={
        "flex items-center gap-0.5 rounded-pill border border-mk-border bg-mk-surface p-0.5 " +
        (className ?? "")
      }
    >
      {IDIOMAS.map((idioma) => {
        const esActual = idioma === (actual as Idioma);
        const Bandera = BANDERAS[idioma];

        return (
          <a
            key={idioma}
            href={inicioDelSitio(idioma)}
            hrefLang={idioma}
            aria-current={esActual ? "true" : undefined}
            /* El nombre del idioma, no el del país: para quien no ve la
               bandera, "English" es la información útil. */
            aria-label={NOMBRE_DE_IDIOMA[idioma]}
            className={
              "grid size-[34px] place-items-center rounded-full transition-opacity " +
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-mk-turquoise " +
              (esActual
                ? "opacity-100 ring-2 ring-mk-turquoise"
                : "opacity-45 hover:opacity-90")
            }
          >
            <Bandera />
          </a>
        );
      })}
    </nav>
  );
}
