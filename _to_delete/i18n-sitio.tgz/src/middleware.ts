import createMiddleware from "next-intl/middleware";

import { routing } from "@/i18n/routing";

export default createMiddleware(routing);

/**
 * **El matcher es una lista blanca, y eso es lo importante de este archivo.**
 *
 * Lo habitual es excluir con una expresión negativa ("todo menos /api y
 * /_next"). Acá no: el middleware corre antes de cada pedido que abarque, y
 * `/r/[code]` es el destino de un toque de pulsera — la pantalla que tiene que
 * abrir lo más rápido posible, muchas veces con una barra de señal. No hay
 * ninguna razón para hacerle pagar un salto extra, y una expresión negativa
 * mal escrita la incluiría sin que nadie se entere hasta que un cliente se
 * queje de que la página tarda.
 *
 * Entonces solo entran las rutas del sitio comercial: la raíz y las dos
 * prefijadas.
 *
 * **`/es` NO está en la lista, y es a propósito.** Con `localePrefix:
 * "as-needed"` el castellano no lleva prefijo: para servir `/`, el middleware
 * reescribe internamente a `/es`. En producción esa reescritura vuelve a pasar
 * por el middleware, que ve un pedido a `/es`, cumple su regla de "el idioma
 * principal no va prefijado" y redirige a `/` — y ahí arranca un bucle
 * infinito de redirecciones. En `next dev` no pasa: la reescritura no
 * reentra, así que el error solo aparece en el build de producción.
 *
 * Dejándolo afuera, `/es` renderiza la home en castellano sin redirigir. No es
 * un problema de contenido duplicado porque su `canonical` apunta a `/`, y
 * además `robots.txt` la excluye.
 *
 * Los paneles, el login, `/empresa`, `/api`, `/pulsera` y `/r` tampoco pasan
 * por acá: su idioma se resuelve dentro del render, en `src/i18n/request.ts`.
 */
export const config = {
  matcher: ["/", "/(en|it)", "/(en|it)/:path*"],
};
