import { defineRouting } from "next-intl/routing";

import { COOKIE_IDIOMA, COOKIE_IDIOMA_MAX_AGE, IDIOMAS, IDIOMA_POR_DEFECTO } from "./locales";

/**
 * El ruteo por idioma del **sitio comercial** (`/`, `/en`, `/it`).
 *
 * Acá sí va el idioma en la URL, al revés que en las páginas de la pulsera.
 * La diferencia no es de gusto: la landing del restaurante tiene su dirección
 * grabada en un chip y no puede cambiar, mientras que el sitio comercial no
 * tiene esa atadura — y sin una URL propia por idioma, Google indexa una sola
 * versión y traducir la web no sirve de nada para búsquedas.
 *
 * `localePrefix: "as-needed"` deja el castellano en la raíz limpia (`/`) y
 * prefija solo los otros dos (`/en`, `/it`). Es lo que corresponde cuando hay
 * un idioma principal claro: la URL que se comparte y se imprime es `/`.
 *
 * La cookie es la MISMA que usan la landing y la carta. Que fueran dos
 * cookies distintas —la de next-intl se llama `NEXT_LOCALE` por defecto— haría
 * que alguien pusiera inglés en la carta y al abrir la web comercial siguiera
 * en castellano, sin ninguna razón visible.
 */
export const routing = defineRouting({
  locales: IDIOMAS,
  defaultLocale: IDIOMA_POR_DEFECTO,
  localePrefix: "as-needed",
  localeCookie: {
    name: COOKIE_IDIOMA,
    maxAge: COOKIE_IDIOMA_MAX_AGE,
    sameSite: "lax",
  },
});
