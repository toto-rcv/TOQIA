"use client";

import Link from "next/link";
import { ArrowLeft, Info, Search, X } from "lucide-react";
import * as React from "react";

import type { MenuCategoryRow, MenuItemRow } from "@/db/queries/menu";
import type { LandingData } from "./landing-view";

/**
 * La carta del local, tal como la ve el cliente.
 *
 * Ambiente propio, distinto de la portada negra: fondo arena, tipografía
 * redonda y bandas de color por categoría. La carta se lee sentado a la mesa,
 * con la luz de la sala; un fondo claro cansa mucho menos que texto claro
 * sobre negro, y una serif editorial hace parecer cara una milanesa.
 *
 * Jerarquía, de más a menos peso visual:
 *   categoría (banda de color) → nombre → precio → descripción → foto
 *
 * Es un componente de cliente por dos cosas que necesitan el navegador: el
 * buscador y el visor de fotos ampliadas.
 */
export function MenuView({
  landing,
  categories,
  currency,
  backHref,
}: {
  landing: LandingData;
  categories: MenuCategoryRow[];
  currency: string;
  /** A dónde vuelve el botón de atrás: siempre la página de esa pulsera. */
  backHref: string;
}) {
  const nombre = landing.displayName?.trim() || landing.name;

  const [busqueda, setBusqueda] = React.useState("");
  const [ampliada, setAmpliada] = React.useState<MenuItemRow | null>(null);

  // Una categoría sin platos visibles no aporta nada y deja un título huérfano.
  const conPlatos = React.useMemo(
    () => categories.filter((categoria) => categoria.items.length > 0),
    [categories]
  );

  const filtradas = React.useMemo(() => {
    const texto = normalizar(busqueda);
    if (texto === "") return conPlatos;

    return conPlatos
      .map((categoria) => ({
        ...categoria,
        items: categoria.items.filter(
          (plato) =>
            normalizar(plato.name).includes(texto) ||
            normalizar(plato.description ?? "").includes(texto)
        ),
      }))
      .filter((categoria) => categoria.items.length > 0);
  }, [conPlatos, busqueda]);

  const totalFiltrado = filtradas.reduce(
    (suma, categoria) => suma + categoria.items.length,
    0
  );

  return (
    <main className="tq-menu-page tq-menu">
      <div className="mx-auto w-full max-w-[520px] px-4 pb-12 pt-3">
        {/* ── Cabecera ─────────────────────────────────────────────────── */}
        <header className="flex items-center gap-2 py-2">
          <Link
            href={backHref}
            aria-label="Volver"
            className="grid size-10 shrink-0 place-items-center rounded-full
                       text-tq-sand-ink transition-colors active:bg-tq-sand-deep"
          >
            <ArrowLeft className="size-5" aria-hidden />
          </Link>

          <h1 className="min-w-0 flex-1 truncate text-center text-[15px] font-extrabold uppercase tracking-[0.1em] text-tq-sand-ink">
            {nombre}
          </h1>

          {landing.address ? (
            <a
              href={backHref}
              aria-label="Volver a la página del local"
              title={landing.address}
              className="grid size-10 shrink-0 place-items-center rounded-full
                         text-tq-sand-soft transition-colors active:bg-tq-sand-deep"
            >
              <Info className="size-5" aria-hidden />
            </a>
          ) : (
            <span className="size-10 shrink-0" aria-hidden />
          )}
        </header>

        {/* ── Buscador ─────────────────────────────────────────────────── */}
        <div className="relative mt-1">
          <Search
            className="pointer-events-none absolute left-4 top-1/2 size-[18px] -translate-y-1/2 text-tq-sand-muted"
            aria-hidden
          />
          <input
            type="search"
            value={busqueda}
            onChange={(event) => setBusqueda(event.target.value)}
            placeholder="Buscar en la carta…"
            aria-label="Buscar en la carta"
            className="h-12 w-full rounded-pill border border-tq-sand-line bg-tq-sand-card
                       pl-11 pr-10 text-[14px] font-medium text-tq-sand-ink
                       placeholder:text-tq-sand-muted focus:border-tq-terracotta
                       focus:outline-none focus:ring-4 focus:ring-tq-terracotta/12
                       [&::-webkit-search-cancel-button]:hidden"
          />
          {busqueda ? (
            <button
              type="button"
              onClick={() => setBusqueda("")}
              aria-label="Borrar la búsqueda"
              className="absolute right-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center
                         rounded-full text-tq-sand-soft"
            >
              <X className="size-4" aria-hidden />
            </button>
          ) : null}
        </div>

        {/* ── Imagen de cabecera ───────────────────────────────────────── */}
        {landing.menuHeaderImageUrl && busqueda === "" ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={landing.menuHeaderImageUrl}
            alt=""
            className="mt-4 aspect-[16/9] w-full rounded-3xl object-cover"
          />
        ) : null}

        {/* ── Categorías y platos ──────────────────────────────────────── */}
        {conPlatos.length === 0 ? (
          <p className="py-16 text-center text-[14px] font-medium text-tq-sand-muted">
            La carta todavía no está cargada.
          </p>
        ) : totalFiltrado === 0 ? (
          <p className="py-16 text-center text-[14px] font-medium text-tq-sand-muted">
            No encontramos nada con “{busqueda}”.
          </p>
        ) : (
          <div className="mt-5 space-y-7">
            {filtradas.map((categoria, indice) => (
              <Categoria
                key={categoria.id}
                categoria={categoria}
                indice={indice}
                currency={currency}
                onAmpliar={setAmpliada}
              />
            ))}
          </div>
        )}

        <p className="mt-10 text-center text-[11px] font-semibold uppercase tracking-[0.16em] text-tq-sand-muted">
          Powered by <span className="text-tq-sand-soft">Toqia</span>
        </p>
      </div>

      <Lightbox plato={ampliada} onClose={() => setAmpliada(null)} />
    </main>
  );
}

/* ── Categoría ────────────────────────────────────────────────────────────── */

function Categoria({
  categoria,
  indice,
  currency,
  onAmpliar,
}: {
  categoria: MenuCategoryRow;
  indice: number;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  // Alterna terracota y café para que dos bandas seguidas no se confundan.
  const oscura = indice % 2 === 1;

  // La foto del círculo sale del primer plato con imagen de esa categoría: es
  // representativa por definición y no obliga al restaurante a cargar una foto
  // más solo para decorar.
  const portada = categoria.items.find((plato) => plato.imageUrl)?.imageUrl ?? null;

  return (
    <section>
      <div
        className={
          "tq-cat-band " + (oscura ? "bg-tq-espresso" : "bg-tq-terracotta")
        }
      >
        <h2 className="tq-cat-title truncate">{categoria.name}</h2>

        {portada ? (
          // -right-1 hace que el círculo se salga apenas de la banda, como en
          // el diseño: rompe el rectángulo y da profundidad.
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={portada}
            alt=""
            className="absolute -right-1 top-1/2 size-[62px] -translate-y-1/2 rounded-full
                       border-[3px] border-tq-sand object-cover"
          />
        ) : null}
      </div>

      {categoria.description ? (
        <p className="mt-2.5 px-1 text-[12.5px] font-medium text-tq-sand-soft">
          {categoria.description}
        </p>
      ) : null}

      <ul className="mt-3 space-y-1.5">
        {categoria.items.map((plato) => (
          <li key={plato.id}>
            <Plato plato={plato} currency={currency} onAmpliar={onAmpliar} />
          </li>
        ))}
      </ul>
    </section>
  );
}

/* ── Plato ────────────────────────────────────────────────────────────────── */

function Plato({
  plato,
  currency,
  onAmpliar,
}: {
  plato: MenuItemRow;
  currency: string;
  onAmpliar: (plato: MenuItemRow) => void;
}) {
  return (
    <div className={"tq-dish " + (plato.available ? "" : "opacity-60")}>
      {/* Sin precio no se reserva el hueco: la ficha desaparece y el nombre
          se corre a la izquierda, en vez de dejar un vacío que parece un error. */}
      {plato.price ? (
        <span className="tq-price">{formatPrice(plato.price, currency)}</span>
      ) : null}

      <div className="min-w-0 flex-1">
        <h3
          className={
            "tq-dish-name " + (plato.available ? "" : "line-through")
          }
        >
          {plato.name}
        </h3>

        {plato.description ? (
          <p className="tq-dish-desc">{plato.description}</p>
        ) : null}

        {!plato.available ? (
          <p className="mt-1 text-[10.5px] font-bold uppercase tracking-[0.08em] text-tq-terracotta">
            Hoy no disponible
          </p>
        ) : null}
      </div>

      {plato.imageUrl ? (
        <button
          type="button"
          onClick={() => onAmpliar(plato)}
          aria-label={`Ver la foto de ${plato.name}`}
          className="shrink-0 overflow-hidden rounded-xl transition-transform duration-150
                     active:scale-95"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl}
            alt={plato.name}
            className="size-[62px] object-cover"
          />
        </button>
      ) : null}
    </div>
  );
}

/* ── Visor de foto ampliada ───────────────────────────────────────────────── */

/**
 * Se usa `<dialog>` nativo y no un div con z-index: el navegador se encarga
 * solo del foco, de la tecla Esc y de dejar el resto de la página inerte. Eso
 * es exactamente lo que hace que funcione igual con teclado en la computadora
 * y con el dedo en el celular.
 */
function Lightbox({
  plato,
  onClose,
}: {
  plato: MenuItemRow | null;
  onClose: () => void;
}) {
  const ref = React.useRef<HTMLDialogElement>(null);

  React.useEffect(() => {
    const dialogo = ref.current;
    if (!dialogo) return;

    if (plato && !dialogo.open) dialogo.showModal();
    if (!plato && dialogo.open) dialogo.close();
  }, [plato]);

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      // Un clic en el fondo cierra. El contenido detiene la propagación para
      // que tocar la foto no la cierre sin querer.
      onClick={onClose}
      className="tq-lightbox m-0 max-h-none max-w-none bg-transparent p-0"
      style={{ width: "100vw", height: "100dvh" }}
    >
      {plato ? (
        <div
          className="flex h-full w-full flex-col items-center justify-center gap-4 p-4"
          onClick={(event) => event.stopPropagation()}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={plato.imageUrl ?? ""}
            alt={plato.name}
            className="max-h-[72vh] w-auto max-w-full rounded-2xl object-contain"
          />

          <div className="max-w-[460px] text-center">
            <p className="text-[16px] font-bold text-white">{plato.name}</p>
            {plato.description ? (
              <p className="mt-1 text-[13px] font-medium leading-snug text-white/70">
                {plato.description}
              </p>
            ) : null}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-12 items-center gap-2 rounded-pill bg-white/20 px-6
                       text-[14px] font-semibold text-white
                       transition-colors active:bg-white/30"
          >
            <X className="size-4" aria-hidden />
            Cerrar
          </button>
        </div>
      ) : null}
    </dialog>
  );
}

/* ── Auxiliares ───────────────────────────────────────────────────────────── */

/**
 * El precio llega como string desde MySQL (columna decimal) para no perder
 * centavos en el camino. Se le saca el ".00" cuando es redondo, que es como lo
 * escribe una carta de verdad.
 */
function formatPrice(price: string, currency: string): string {
  const numero = Number(price);
  if (!Number.isFinite(numero)) return `${price} ${currency}`;

  const texto = Number.isInteger(numero)
    ? String(numero)
    : numero.toFixed(2).replace(".", ",");

  return `${currency}${texto}`;
}

/** Para buscar sin que las tildes ni las mayúsculas estorben. */
function normalizar(texto: string): string {
  return texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}
